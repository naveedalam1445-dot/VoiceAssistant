package com.voiceassistant.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.voiceassistant.R;
import com.voiceassistant.commands.CommandProcessor;
import com.voiceassistant.voice.SpeechRecognitionManager;
import com.voiceassistant.voice.TextToSpeechManager;
import com.voiceassistant.voice.VoiceRecognitionListener;

import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity — the single Activity that hosts the entire UI.
 * Responsibilities:
 *   - Bootstrap TTS, Speech recognition, and command processor.
 *   - Own the runtime-permission flow.
 *   - Drive the status / transcript UI updates.
 */
public class MainActivity extends AppCompatActivity implements VoiceRecognitionListener {

    // ──────────────────────────────────────────────────────────
    // Constants
    // ──────────────────────────────────────────────────────────
    private static final int PERMISSION_REQUEST_CODE = 100;

    /** All permissions the app may ever need, requested upfront. */
    private static final String[] REQUIRED_PERMISSIONS = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.BLUETOOTH_CONNECT  // API 31+
    };

    // ──────────────────────────────────────────────────────────
    // UI References
    // ──────────────────────────────────────────────────────────
    private ImageButton btnMic;
    private TextView    tvStatus;
    private TextView    tvCommand;
    private TextView    tvResponse;
    private LinearLayout waveContainer;
    private View        pulseRing;

    // ──────────────────────────────────────────────────────────
    // Core Managers
    // ──────────────────────────────────────────────────────────
    private SpeechRecognitionManager speechManager;
    private TextToSpeechManager      ttsManager;
    private CommandProcessor         commandProcessor;

    private boolean isListening = false;
    private Vibrator vibrator;
    private Handler  handler;

    // ──────────────────────────────────────────────────────────
    // Lifecycle
    // ──────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        handler  = new Handler(Looper.getMainLooper());
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        bindViews();
        setupManagers();
        requestPermissionsIfNeeded();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speechManager != null) speechManager.destroy();
        if (ttsManager    != null) ttsManager.shutdown();
    }

    // ──────────────────────────────────────────────────────────
    // Initialisation helpers
    // ──────────────────────────────────────────────────────────

    private void bindViews() {
        btnMic       = findViewById(R.id.btnMic);
        tvStatus     = findViewById(R.id.tvStatus);
        tvCommand    = findViewById(R.id.tvCommand);
        tvResponse   = findViewById(R.id.tvResponse);
        waveContainer = findViewById(R.id.waveContainer);
        pulseRing    = findViewById(R.id.pulseRing);

        btnMic.setOnClickListener(v -> onMicClicked());
    }

    private void setupManagers() {
        // TextToSpeech must be initialised first so CommandProcessor can use it.
        ttsManager = new TextToSpeechManager(this);

        commandProcessor = new CommandProcessor(this, ttsManager);

        speechManager = new SpeechRecognitionManager(this, this);
    }

    // ──────────────────────────────────────────────────────────
    // Permission handling
    // ──────────────────────────────────────────────────────────

    private void requestPermissionsIfNeeded() {
        List<String> missing = new ArrayList<>();
        for (String perm : REQUIRED_PERMISSIONS) {
            // BLUETOOTH_CONNECT only matters on API 31+
            if (perm.equals(Manifest.permission.BLUETOOTH_CONNECT)
                    && Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                continue;
            }
            if (ContextCompat.checkSelfPermission(this, perm)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(perm);
            }
        }

        if (!missing.isEmpty()) {
            ActivityCompat.requestPermissions(
                    this,
                    missing.toArray(new String[0]),
                    PERMISSION_REQUEST_CODE);
        } else {
            onAllPermissionsGranted();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[]  permissions,
                                           @NonNull int[]     grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            // RECORD_AUDIO is the only truly blocking permission.
            boolean audioGranted = ContextCompat.checkSelfPermission(
                    this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED;

            if (audioGranted) {
                onAllPermissionsGranted();
            } else {
                updateStatus("Microphone permission required");
                updateResponse("Please grant microphone access and restart the app.");
            }
        }
    }

    private void onAllPermissionsGranted() {
        updateStatus("Tap mic to speak");
        ttsManager.speak("Voice Assistant ready. Tap the mic and speak a command.");
    }

    // ──────────────────────────────────────────────────────────
    // Mic button logic
    // ──────────────────────────────────────────────────────────

    private void onMicClicked() {
        vibrateShort();

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Speech recognition unavailable");
            updateResponse("Your device does not support offline speech recognition.");
            return;
        }

        if (isListening) {
            stopListening();
        } else {
            startListening();
        }
    }

    private void startListening() {
        isListening = true;
        btnMic.setImageResource(R.drawable.ic_mic_active);
        updateStatus("Listening…");
        updateCommand("");
        updateResponse("");
        startPulseAnimation();
        speechManager.startListening();
    }

    private void stopListening() {
        isListening = false;
        btnMic.setImageResource(R.drawable.ic_mic);
        updateStatus("Tap mic to speak");
        stopPulseAnimation();
        speechManager.stopListening();
    }

    // ──────────────────────────────────────────────────────────
    // VoiceRecognitionListener callbacks (called on main thread)
    // ──────────────────────────────────────────────────────────

    @Override
    public void onRecognitionResult(String recognizedText) {
        stopListening();
        updateCommand(recognizedText);
        updateStatus("Processing…");
        // Slight delay so the user can read the recognised text before TTS fires.
        handler.postDelayed(() -> {
            String response = commandProcessor.process(recognizedText);
            updateResponse(response);
            updateStatus("Tap mic to speak");
        }, 300);
    }

    @Override
    public void onRecognitionError(int errorCode, String errorMessage) {
        stopListening();
        updateStatus("Tap mic to speak");
        updateResponse("Could not understand. Please try again.");
        ttsManager.speak("Sorry, I did not catch that. Please try again.");
    }

    @Override
    public void onReadyForSpeech() {
        updateStatus("Listening… speak now");
    }

    // ──────────────────────────────────────────────────────────
    // UI update helpers (all safe to call from any thread)
    // ──────────────────────────────────────────────────────────

    public void updateStatus(String text) {
        runOnUiThread(() -> tvStatus.setText(text));
    }

    public void updateCommand(String text) {
        runOnUiThread(() -> {
            tvCommand.setText(text.isEmpty() ? "" : "You said: \"" + text + "\"");
            tvCommand.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);
        });
    }

    public void updateResponse(String text) {
        runOnUiThread(() -> {
            tvResponse.setText(text);
            tvResponse.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);
        });
    }

    // ──────────────────────────────────────────────────────────
    // Animations
    // ──────────────────────────────────────────────────────────

    private void startPulseAnimation() {
        pulseRing.setVisibility(View.VISIBLE);
        Animation pulse = AnimationUtils.loadAnimation(this, R.anim.pulse);
        pulseRing.startAnimation(pulse);
    }

    private void stopPulseAnimation() {
        pulseRing.clearAnimation();
        pulseRing.setVisibility(View.INVISIBLE);
    }

    // ──────────────────────────────────────────────────────────
    // Misc
    // ──────────────────────────────────────────────────────────

    private void vibrateShort() {
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                        android.os.VibrationEffect.createOneShot(
                                50, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                //noinspection deprecation
                vibrator.vibrate(50);
            }
        }
    }
}
