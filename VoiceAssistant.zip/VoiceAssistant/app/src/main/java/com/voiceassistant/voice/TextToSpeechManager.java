package com.voiceassistant.voice;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;

import java.util.Locale;

/**
 * TextToSpeechManager
 *
 * Thin wrapper around Android's built-in {@link TextToSpeech} engine.
 * No internet is required — TTS is always fully offline on Android.
 */
public class TextToSpeechManager {

    private static final String TAG         = "TTSManager";
    private static final String UTTERANCE_ID = "VA_UTTERANCE";

    private TextToSpeech tts;
    private boolean      ready = false;

    // Queue of messages requested before TTS was ready.
    private String pendingMessage = null;

    // ──────────────────────────────────────────────────────────
    // Constructor
    // ──────────────────────────────────────────────────────────

    public TextToSpeechManager(Context context) {
        tts = new TextToSpeech(context.getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(Locale.getDefault());
                if (result == TextToSpeech.LANG_MISSING_DATA
                        || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    // Fall back to English if device locale is unsupported.
                    tts.setLanguage(Locale.ENGLISH);
                }

                // Slightly slower, clearer speech.
                tts.setSpeechRate(0.9f);
                tts.setPitch(1.0f);

                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { }
                    @Override public void onDone(String utteranceId) { }
                    @Override public void onError(String utteranceId) {
                        Log.w(TAG, "TTS error for utterance: " + utteranceId);
                    }
                });

                ready = true;
                Log.d(TAG, "TTS ready");

                // Flush any message that arrived before we were ready.
                if (pendingMessage != null) {
                    speak(pendingMessage);
                    pendingMessage = null;
                }
            } else {
                Log.e(TAG, "TTS initialisation failed, status=" + status);
            }
        });
    }

    // ──────────────────────────────────────────────────────────
    // Public API
    // ──────────────────────────────────────────────────────────

    /**
     * Speak {@code text}, interrupting any currently playing speech.
     * Safe to call before TTS has finished initialising (message is queued).
     */
    public void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;

        if (!ready) {
            pendingMessage = text;
            return;
        }

        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID);
    }

    /**
     * Stop any currently playing speech without destroying the engine.
     */
    public void stop() {
        if (tts != null && ready) {
            tts.stop();
        }
    }

    /**
     * Release the TTS engine — call from Activity.onDestroy().
     */
    public void shutdown() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts   = null;
            ready = false;
        }
    }

    /** @return {@code true} if the engine is initialised and ready to speak. */
    public boolean isReady() {
        return ready;
    }
}
