# VoiceAssistant — Offline AI Voice Assistant for Android

A fully offline, Java-based Android voice assistant that requires **no internet connection**
for recognition or TTS.

---

## Features

| Voice Command | Action |
|---|---|
| "Open camera" | Launches the camera app |
| "Open gallery" / "Open photos" | Opens the gallery |
| "Turn on / off flashlight" | Toggles the torch via CameraManager |
| "Turn on / off Bluetooth" | Enables/disables Bluetooth (opens Settings on API 33+) |
| "Turn on / off WiFi" | Opens WiFi panel / toggles WiFi |
| "Open WhatsApp" | Launches WhatsApp (or Play Store if not installed) |
| "Open [any app name]" | Fuzzy-searches installed apps and launches the best match |
| "Call [contact name]" | Dials the contact via Contacts DB |
| "What time is it?" | Reads the current time |
| "What date is it?" | Reads the current date |
| "Battery level" | Reports battery % and charging state |
| "Volume up / down" | Adjusts media volume |
| "Mute / unmute" | Toggles silent / ring mode |

---

## Architecture

```
com.voiceassistant/
├── activities/
│   └── MainActivity.java          ← UI, permission flow, wires everything together
├── voice/
│   ├── VoiceRecognitionListener.java  ← Callback interface
│   ├── SpeechRecognitionManager.java  ← Wraps Android SpeechRecognizer
│   └── TextToSpeechManager.java       ← Wraps Android TTS engine
├── commands/
│   └── CommandProcessor.java      ← Classifies raw text → Command enum
└── executor/
    └── ActionExecutor.java        ← Executes device actions + returns responses
```

---

## Requirements

- **Android Studio** Hedgehog (2023.1.1) or newer
- **Java 8** (already configured in build.gradle)
- **Android API 23+** (Android 6.0 Marshmallow)
- A real Android device with an **offline speech model** installed for fully offline
  operation (Pixel devices, most Samsung flagships).  On devices without an offline
  model the OS falls back to online recognition automatically.

---

## How to Build & Run

1. Open **Android Studio** → *File → Open* → select the `VoiceAssistant` folder.
2. Wait for Gradle sync to finish.
3. Connect a physical Android device (speech recognition works best on real hardware).
4. Click ▶ **Run** (or `Shift+F10`).
5. Grant the requested permissions (Microphone is mandatory; all others enable extra features).

---

## Offline Speech Recognition

Android's `SpeechRecognizer` sends audio to Google's servers by default.  To make it
**fully offline**:

1. Go to **Settings → System → Languages → Offline speech recognition** (exact path varies
   by device/manufacturer).
2. Download the language model for your language.
3. Once installed, recognition works with no network.

The app already sets `EXTRA_PREFER_OFFLINE = true` in the recognizer intent, so it will
use the offline model automatically when available.

---

## Permissions Used

| Permission | Purpose |
|---|---|
| `RECORD_AUDIO` | Voice recognition |
| `CALL_PHONE` | Dialling contacts |
| `READ_CONTACTS` | Looking up contact phone numbers |
| `CAMERA` | Launching camera + flashlight via CameraManager |
| `BLUETOOTH` / `BLUETOOTH_CONNECT` | Enabling/disabling Bluetooth |
| `CHANGE_WIFI_STATE` | Enabling/disabling WiFi (API < 29) |
| `READ_EXTERNAL_STORAGE` / `READ_MEDIA_IMAGES` | Opening gallery |
| `VIBRATE` | Haptic feedback on mic button tap |

---

## Limitations & Notes

- **WiFi toggle**: Android 10+ (API 29) prevents third-party apps from programmatically
  toggling WiFi.  The app opens the system WiFi panel instead.
- **Bluetooth toggle**: Android 13+ (API 33) similarly restricts this; the app opens
  Bluetooth Settings as a fallback.
- **Calling**: Requires the `CALL_PHONE` permission and a contact stored on the device.
- **"Open [app]" fallback**: Works for any installed app whose label matches the spoken name.
