package com.voiceassistant.voice;

/**
 * Callback interface delivered from {@link SpeechRecognitionManager}
 * back to the Activity (or any other consumer).
 *
 * All methods are guaranteed to be called on the main thread.
 */
public interface VoiceRecognitionListener {

    /**
     * Called when the recogniser has a final transcription.
     *
     * @param recognizedText The best hypothesis returned by the engine.
     */
    void onRecognitionResult(String recognizedText);

    /**
     * Called when the recogniser encounters an unrecoverable error.
     *
     * @param errorCode    Android SpeechRecognizer error constant.
     * @param errorMessage Human-readable description for logging / display.
     */
    void onRecognitionError(int errorCode, String errorMessage);

    /**
     * Called as soon as the microphone is open and the engine is ready.
     * Use this to update "Listening…" UI state.
     */
    void onReadyForSpeech();
}
