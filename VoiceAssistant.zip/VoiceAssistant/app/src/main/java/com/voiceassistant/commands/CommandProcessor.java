package com.voiceassistant.commands;

import android.content.Context;
import android.util.Log;

import com.voiceassistant.executor.ActionExecutor;
import com.voiceassistant.voice.TextToSpeechManager;

/**
 * CommandProcessor
 *
 * Receives a raw transcription string, classifies it into a {@link Command},
 * delegates execution to {@link ActionExecutor}, and returns a user-facing
 * response string.
 *
 * Classification is done with simple keyword/pattern matching — no ML or
 * internet required.
 */
public class CommandProcessor {

    private static final String TAG = "CmdProcessor";

    private final ActionExecutor    executor;
    private final TextToSpeechManager tts;

    // ──────────────────────────────────────────────────────────
    // Constructor
    // ──────────────────────────────────────────────────────────

    public CommandProcessor(Context context, TextToSpeechManager tts) {
        this.tts      = tts;
        this.executor = new ActionExecutor(context, tts);
    }

    // ──────────────────────────────────────────────────────────
    // Public entry-point
    // ──────────────────────────────────────────────────────────

    /**
     * Process a raw voice command string.
     *
     * @param rawText The transcribed user utterance (already lowercased by caller).
     * @return A human-readable response to display in the UI.
     */
    public String process(String rawText) {
        if (rawText == null || rawText.trim().isEmpty()) {
            return respond("I didn't catch that. Please try again.");
        }

        String text = rawText.toLowerCase().trim();
        Log.d(TAG, "Processing: " + text);

        // ── Camera ──────────────────────────────────────────
        if (contains(text, "open camera", "launch camera", "take photo",
                "take picture", "camera")) {
            return executor.openCamera();
        }

        // ── Gallery ─────────────────────────────────────────
        if (contains(text, "open gallery", "open photos", "view photos",
                "view gallery", "gallery", "photos")) {
            return executor.openGallery();
        }

        // ── Flashlight ON ───────────────────────────────────
        if (contains(text, "turn on flashlight", "flashlight on",
                "enable flashlight", "switch on flashlight",
                "torch on", "turn on torch")) {
            return executor.setFlashlight(true);
        }

        // ── Flashlight OFF ──────────────────────────────────
        if (contains(text, "turn off flashlight", "flashlight off",
                "disable flashlight", "switch off flashlight",
                "torch off", "turn off torch")) {
            return executor.setFlashlight(false);
        }

        // ── Bluetooth ON ────────────────────────────────────
        if (contains(text, "turn on bluetooth", "bluetooth on",
                "enable bluetooth", "switch on bluetooth")) {
            return executor.setBluetooth(true);
        }

        // ── Bluetooth OFF ───────────────────────────────────
        if (contains(text, "turn off bluetooth", "bluetooth off",
                "disable bluetooth", "switch off bluetooth")) {
            return executor.setBluetooth(false);
        }

        // ── WiFi ON ─────────────────────────────────────────
        if (contains(text, "turn on wifi", "wifi on", "enable wifi",
                "switch on wifi", "turn on wi-fi", "wi-fi on")) {
            return executor.setWifi(true);
        }

        // ── WiFi OFF ────────────────────────────────────────
        if (contains(text, "turn off wifi", "wifi off", "disable wifi",
                "switch off wifi", "turn off wi-fi", "wi-fi off")) {
            return executor.setWifi(false);
        }

        // ── WhatsApp ────────────────────────────────────────
        if (contains(text, "open whatsapp", "whatsapp")) {
            return executor.openApp("com.whatsapp", "WhatsApp");
        }

        // ── YouTube ─────────────────────────────────────────
        if (contains(text, "open youtube", "youtube")) {
            return executor.openApp("com.google.android.youtube", "YouTube");
        }

        // ── Instagram ───────────────────────────────────────
        if (contains(text, "open instagram", "instagram")) {
            return executor.openApp("com.instagram.android", "Instagram");
        }

        // ── Facebook ────────────────────────────────────────
        if (contains(text, "open facebook", "facebook")) {
            return executor.openApp("com.facebook.katana", "Facebook");
        }

        // ── Twitter / X ─────────────────────────────────────
        if (contains(text, "open twitter", "twitter", "open x")) {
            return executor.openApp("com.twitter.android", "Twitter");
        }

        // ── Snapchat ────────────────────────────────────────
        if (contains(text, "open snapchat", "snapchat")) {
            return executor.openApp("com.snapchat.android", "Snapchat");
        }

        // ── Gmail ───────────────────────────────────────────
        if (contains(text, "open gmail", "gmail", "open email", "email")) {
            return executor.openApp("com.google.android.gm", "Gmail");
        }

        // ── Chrome ──────────────────────────────────────────
        if (contains(text, "open chrome", "chrome", "open browser", "browser")) {
            return executor.openApp("com.android.chrome", "Chrome");
        }

        // ── Google Maps ─────────────────────────────────────
        if (contains(text, "open maps", "maps", "open google maps")) {
            return executor.openApp("com.google.android.apps.maps", "Google Maps");
        }

        // ── Spotify ─────────────────────────────────────────
        if (contains(text, "open spotify", "spotify")) {
            return executor.openApp("com.spotify.music", "Spotify");
        }

        // ── Calculator ──────────────────────────────────────
        if (contains(text, "open calculator", "calculator")) {
            return executor.openCalculator();
        }

        // ── Settings ────────────────────────────────────────
        if (contains(text, "open settings", "settings")) {
            return executor.openSettings();
        }

        // ── Contacts ────────────────────────────────────────
        if (contains(text, "open contacts", "contacts")) {
            return executor.openContacts();
        }

        // ── Call [name] ─────────────────────────────────────
        // Must come AFTER all "open X" patterns to avoid false match.
        if (text.startsWith("call ") || contains(text, "dial ", "phone ")) {
            String contactName = extractContactName(text);
            if (contactName != null && !contactName.isEmpty()) {
                return executor.callContact(contactName);
            }
        }

        // ── Time ────────────────────────────────────────────
        if (contains(text, "what time", "current time", "tell me the time",
                "what's the time")) {
            return executor.tellTime();
        }

        // ── Date ────────────────────────────────────────────
        if (contains(text, "what date", "what's the date", "today's date",
                "current date")) {
            return executor.tellDate();
        }

        // ── Battery ─────────────────────────────────────────
        if (contains(text, "battery", "battery level", "how much battery")) {
            return executor.tellBattery();
        }

        // ── Volume UP ───────────────────────────────────────
        if (contains(text, "volume up", "increase volume", "louder",
                "turn up volume")) {
            return executor.changeVolume(true);
        }

        // ── Volume DOWN ─────────────────────────────────────
        if (contains(text, "volume down", "decrease volume", "quieter",
                "turn down volume", "lower volume")) {
            return executor.changeVolume(false);
        }

        // ── Mute ────────────────────────────────────────────
        if (contains(text, "mute", "silent mode", "silence")) {
            return executor.setMute(true);
        }

        // ── Unmute ──────────────────────────────────────────
        if (contains(text, "unmute", "sound on", "ring mode")) {
            return executor.setMute(false);
        }

        // ──────────────────────────────────────────────────────
        // Generic "open <app name>" fallback
        // Attempt to resolve any remaining "open X" phrase by searching
        // the installed app list.
        // ──────────────────────────────────────────────────────
        if (text.startsWith("open ") || text.startsWith("launch ")) {
            String appName = text.replaceFirst("^(open|launch)\\s+", "").trim();
            if (!appName.isEmpty()) {
                return executor.openAppByName(appName);
            }
        }

        // ── Fallback ────────────────────────────────────────
        return respond("Sorry, I don't know how to handle that command. Try saying "
                + "\"open camera\", \"call someone\", or \"turn on flashlight\".");
    }

    // ──────────────────────────────────────────────────────────
    // Helpers
    // ──────────────────────────────────────────────────────────

    /**
     * Returns {@code true} if {@code text} contains ANY of the given keywords.
     */
    private boolean contains(String text, String... keywords) {
        for (String kw : keywords) {
            if (text.contains(kw)) return true;
        }
        return false;
    }

    /**
     * Extracts the contact name from phrases like:
     *   "call John", "dial Mary Smith", "phone Dad"
     */
    private String extractContactName(String text) {
        // Strip leading verb
        String stripped = text
                .replaceFirst("^call\\s+",  "")
                .replaceFirst("^dial\\s+",  "")
                .replaceFirst("^phone\\s+", "")
                .trim();

        // Remove any trailing filler ("please", "now", etc.)
        stripped = stripped.replaceAll("\\s+(please|now|for me)$", "").trim();

        return stripped;
    }

    /** Speak and return the message. */
    private String respond(String message) {
        tts.speak(message);
        return message;
    }
}
