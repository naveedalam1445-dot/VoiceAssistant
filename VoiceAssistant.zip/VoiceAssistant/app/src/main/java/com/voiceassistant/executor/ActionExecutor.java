package com.voiceassistant.executor;

import android.bluetooth.BluetoothAdapter;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;

import com.voiceassistant.voice.TextToSpeechManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * ActionExecutor
 *
 * Carries out every physical device action the assistant can perform.
 * Each method:
 *   1. Performs the action (Intent, API call, etc.)
 *   2. Speaks a confirmation via TTS
 *   3. Returns a response string for the UI
 */
public class ActionExecutor {

    private static final String TAG = "ActionExecutor";

    private final Context            context;
    private final TextToSpeechManager tts;
    private final CameraManager      cameraManager;
    private final AudioManager       audioManager;
    private       String             flashCameraId = null;
    private       boolean            flashOn       = false;

    // ──────────────────────────────────────────────────────────
    // Constructor
    // ──────────────────────────────────────────────────────────

    public ActionExecutor(Context context, TextToSpeechManager tts) {
        this.context      = context.getApplicationContext();
        this.tts          = tts;
        this.cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        this.audioManager  = (AudioManager)  context.getSystemService(Context.AUDIO_SERVICE);
        initFlashCameraId();
    }

    // ──────────────────────────────────────────────────────────
    // Camera
    // ──────────────────────────────────────────────────────────

    /** Launch the system camera app. */
    public String openCamera() {
        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return respond("Opening camera.");
        } catch (Exception e) {
            Log.e(TAG, "openCamera: " + e.getMessage());
            return respond("Could not open the camera. Please try manually.");
        }
    }

    // ──────────────────────────────────────────────────────────
    // Gallery
    // ──────────────────────────────────────────────────────────

    /** Open the system gallery / photos app. */
    public String openGallery() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setType("image/*");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return respond("Opening gallery.");
        } catch (Exception e) {
            // Fallback: use external content URI
            try {
                Intent fallback = new Intent(Intent.ACTION_VIEW,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(fallback);
                return respond("Opening gallery.");
            } catch (Exception ex) {
                return respond("Could not open the gallery.");
            }
        }
    }

    // ──────────────────────────────────────────────────────────
    // Flashlight
    // ──────────────────────────────────────────────────────────

    /** Turn the flashlight on or off. */
    public String setFlashlight(boolean on) {
        if (flashCameraId == null) {
            return respond("This device does not have a flashlight.");
        }

        if (flashOn == on) {
            String state = on ? "already on" : "already off";
            return respond("Flashlight is " + state + ".");
        }

        try {
            cameraManager.setTorchMode(flashCameraId, on);
            flashOn = on;
            String state = on ? "on" : "off";
            return respond("Flashlight turned " + state + ".");
        } catch (CameraAccessException e) {
            Log.e(TAG, "setFlashlight: " + e.getMessage());
            return respond("Could not control the flashlight. Camera may be in use.");
        }
    }

    // ──────────────────────────────────────────────────────────
    // Bluetooth
    // ──────────────────────────────────────────────────────────

    /** Enable or disable Bluetooth. */
    public String setBluetooth(boolean enable) {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) {
                return respond("This device does not support Bluetooth.");
            }

            if (enable && !adapter.isEnabled()) {
                // On API 33+ enabling Bluetooth programmatically is deprecated;
                // open settings as fallback.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    openBluetoothSettings();
                    return respond("Please enable Bluetooth from the panel that just opened.");
                }
                //noinspection deprecation
                adapter.enable();
                return respond("Turning Bluetooth on.");
            } else if (!enable && adapter.isEnabled()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    openBluetoothSettings();
                    return respond("Please disable Bluetooth from the panel that just opened.");
                }
                //noinspection deprecation
                adapter.disable();
                return respond("Turning Bluetooth off.");
            } else {
                String state = enable ? "already on" : "already off";
                return respond("Bluetooth is " + state + ".");
            }
        } catch (Exception e) {
            Log.e(TAG, "setBluetooth: " + e.getMessage());
            return respond("Could not change Bluetooth state. Please do it manually.");
        }
    }

    // ──────────────────────────────────────────────────────────
    // WiFi
    // ──────────────────────────────────────────────────────────

    /** Enable or disable WiFi. */
    public String setWifi(boolean enable) {
        // On API 29+ setWifiEnabled() is restricted for 3rd-party apps.
        // We open the WiFi settings panel instead, which works on all API levels.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                Intent panelIntent = new Intent(Settings.Panel.ACTION_WIFI);
                panelIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(panelIntent);
                String action = enable ? "enable" : "disable";
                return respond("Please " + action + " WiFi from the panel that opened.");
            } catch (Exception e) {
                return openWifiSettings(enable);
            }
        }

        // Legacy path (API < 29)
        try {
            WifiManager wifiManager =
                    (WifiManager) context.getApplicationContext()
                            .getSystemService(Context.WIFI_SERVICE);
            if (wifiManager != null) {
                //noinspection deprecation
                wifiManager.setWifiEnabled(enable);
                String state = enable ? "on" : "off";
                return respond("WiFi turned " + state + ".");
            }
        } catch (Exception e) {
            Log.e(TAG, "setWifi: " + e.getMessage());
        }
        return openWifiSettings(enable);
    }

    // ──────────────────────────────────────────────────────────
    // App launching — by package name
    // ──────────────────────────────────────────────────────────

    /**
     * Launch a known app by package name, falling back to the Play Store listing.
     */
    public String openApp(String packageName, String appLabel) {
        PackageManager pm = context.getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(packageName);
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return respond("Opening " + appLabel + ".");
        } else {
            // App not installed — open Play Store listing.
            try {
                Intent store = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=" + packageName));
                store.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(store);
                return respond(appLabel + " is not installed. Opening Play Store.");
            } catch (Exception e) {
                return respond(appLabel + " is not installed on this device.");
            }
        }
    }

    // ──────────────────────────────────────────────────────────
    // App launching — by fuzzy name search
    // ──────────────────────────────────────────────────────────

    /**
     * Search the installed app list for an app whose label contains {@code appName},
     * then launch the best match.
     */
    public String openAppByName(String appName) {
        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> apps =
                pm.getInstalledApplications(PackageManager.GET_META_DATA);

        String queryLower = appName.toLowerCase();
        ApplicationInfo bestMatch = null;

        for (ApplicationInfo info : apps) {
            String label = pm.getApplicationLabel(info).toString().toLowerCase();
            if (label.equals(queryLower)) {
                // Exact match — use immediately.
                bestMatch = info;
                break;
            }
            if (label.contains(queryLower) && bestMatch == null) {
                bestMatch = info;
            }
        }

        if (bestMatch != null) {
            Intent intent = pm.getLaunchIntentForPackage(bestMatch.packageName);
            if (intent != null) {
                String label = pm.getApplicationLabel(bestMatch).toString();
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return respond("Opening " + label + ".");
            }
        }

        return respond("I couldn't find an app named \"" + appName
                + "\" on your device.");
    }

    // ──────────────────────────────────────────────────────────
    // System apps
    // ──────────────────────────────────────────────────────────

    public String openCalculator() {
        // Try common calculator package names across manufacturers.
        String[] calculatorPkgs = {
                "com.google.android.calculator",
                "com.android.calculator2",
                "com.miui.calculator",
                "com.sec.android.app.popupcalculator"  // Samsung
        };
        for (String pkg : calculatorPkgs) {
            Intent intent = context.getPackageManager().getLaunchIntentForPackage(pkg);
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return respond("Opening calculator.");
            }
        }
        return respond("Calculator app not found on this device.");
    }

    public String openSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return respond("Opening settings.");
        } catch (Exception e) {
            return respond("Could not open settings.");
        }
    }

    public String openContacts() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    ContactsContract.Contacts.CONTENT_URI);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return respond("Opening contacts.");
        } catch (Exception e) {
            return respond("Could not open contacts.");
        }
    }

    // ──────────────────────────────────────────────────────────
    // Phone calls
    // ──────────────────────────────────────────────────────────

    /**
     * Attempt to call a contact by name.
     * Looks up the contact in the device contacts database and dials.
     */
    public String callContact(String contactName) {
        try {
            String phoneNumber = lookupPhoneNumber(contactName);
            if (phoneNumber != null) {
                Intent intent = new Intent(Intent.ACTION_CALL,
                        Uri.parse("tel:" + phoneNumber));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return respond("Calling " + contactName + ".");
            } else {
                // Fall back to dialer with the name pre-filled so user can pick.
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return respond("Could not find " + contactName
                        + " in your contacts. Opening dialer.");
            }
        } catch (SecurityException se) {
            return respond("Phone call permission is required. "
                    + "Please grant it in Settings and try again.");
        } catch (Exception e) {
            Log.e(TAG, "callContact: " + e.getMessage());
            return respond("Could not place the call. Please try manually.");
        }
    }

    // ──────────────────────────────────────────────────────────
    // System information
    // ──────────────────────────────────────────────────────────

    public String tellTime() {
        String time = new SimpleDateFormat("h:mm a", Locale.getDefault())
                .format(new Date());
        return respond("The current time is " + time + ".");
    }

    public String tellDate() {
        String date = new SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())
                .format(new Date());
        return respond("Today is " + date + ".");
    }

    public String tellBattery() {
        try {
            IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = context.registerReceiver(null, filter);
            if (batteryStatus != null) {
                int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                int pct   = (int) ((level / (float) scale) * 100);
                int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                boolean charging =
                        status == BatteryManager.BATTERY_STATUS_CHARGING
                                || status == BatteryManager.BATTERY_STATUS_FULL;
                String chargingStr = charging ? " and charging" : "";
                return respond("Battery is at " + pct + " percent" + chargingStr + ".");
            }
        } catch (Exception e) {
            Log.e(TAG, "tellBattery: " + e.getMessage());
        }
        return respond("Could not retrieve battery information.");
    }

    // ──────────────────────────────────────────────────────────
    // Volume
    // ──────────────────────────────────────────────────────────

    public String changeVolume(boolean up) {
        int direction = up
                ? AudioManager.ADJUST_RAISE
                : AudioManager.ADJUST_LOWER;
        audioManager.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                direction,
                AudioManager.FLAG_SHOW_UI);
        return respond(up ? "Volume increased." : "Volume decreased.");
    }

    public String setMute(boolean mute) {
        if (mute) {
            audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
            return respond("Phone set to silent mode.");
        } else {
            audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            return respond("Phone set to ring mode.");
        }
    }

    // ──────────────────────────────────────────────────────────
    // Private helpers
    // ──────────────────────────────────────────────────────────

    /** Find the rear camera's ID for torch control. */
    private void initFlashCameraId() {
        try {
            for (String id : cameraManager.getCameraIdList()) {
                Boolean hasFlash = cameraManager
                        .getCameraCharacteristics(id)
                        .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(hasFlash)) {
                    flashCameraId = id;
                    break;
                }
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "initFlashCameraId: " + e.getMessage());
        }
    }

    /**
     * Query the contacts database for a phone number matching {@code name}.
     * Returns the first match or {@code null} if not found.
     */
    private String lookupPhoneNumber(String name) {
        ContentResolver cr   = context.getContentResolver();
        String          num  = null;

        // Step 1: find contact ID
        String contactId = null;
        try (Cursor c = cr.query(
                ContactsContract.Contacts.CONTENT_URI,
                new String[]{ContactsContract.Contacts._ID,
                        ContactsContract.Contacts.DISPLAY_NAME,
                        ContactsContract.Contacts.HAS_PHONE_NUMBER},
                ContactsContract.Contacts.DISPLAY_NAME + " LIKE ?",
                new String[]{"%" + name + "%"},
                null)) {

            if (c != null && c.moveToFirst()) {
                contactId = c.getString(
                        c.getColumnIndexOrThrow(ContactsContract.Contacts._ID));
            }
        } catch (Exception e) {
            Log.e(TAG, "lookupPhoneNumber (contacts): " + e.getMessage());
        }

        if (contactId == null) return null;

        // Step 2: get phone number for that contact ID
        try (Cursor c = cr.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                new String[]{contactId},
                null)) {

            if (c != null && c.moveToFirst()) {
                num = c.getString(
                        c.getColumnIndexOrThrow(
                                ContactsContract.CommonDataKinds.Phone.NUMBER));
            }
        } catch (Exception e) {
            Log.e(TAG, "lookupPhoneNumber (phone): " + e.getMessage());
        }

        return num;
    }

    private void openBluetoothSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "openBluetoothSettings: " + e.getMessage());
        }
    }

    private String openWifiSettings(boolean enable) {
        try {
            Intent intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            String action = enable ? "enable" : "disable";
            return respond("Please " + action + " WiFi from Settings.");
        } catch (Exception e) {
            return respond("Could not change WiFi state. Please do it manually.");
        }
    }

    /** Speak and return the message. */
    private String respond(String message) {
        tts.speak(message);
        return message;
    }
}
