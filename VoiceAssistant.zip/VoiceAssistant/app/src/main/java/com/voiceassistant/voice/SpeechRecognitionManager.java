package com.voiceassistant.voice;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;

import java.util.ArrayList;
import java.util.Locale;

/**
 * SpeechRecognitionManager
 *
 * Wraps Android's {@link SpeechRecognizer} and exposes a simple start / stop API.
 *
 * OFFLINE BEHAVIOUR
 * -----------------
 * We set {@link RecognizerIntent#EXTRA_PREFER_OFFLINE} to {@code true}.
 * On devices with an offline language model installed (Pixel, Samsung with offline
 * voice model, etc.) recognition works without any network.  On devices that lack
 * an offline model the OS will fall back to online recognition automatically, so
 * the app still works – it just won't be fully offline on those devices.
 *
 * Note: SpeechRecognizer must be created and used on the **main thread**.
 */
public class SpeechRecognitionManager {

    private static final String TAG = "SpeechRecMgr";

    private final Context                  context;
    private final VoiceRecognitionListener listener;
    private SpeechRecognizer               recognizer;

    // ──────────────────────────────────────────────────────────
    // Constructor
    // ──────────────────────────────────────────────────────────

    public SpeechRecognitionManager(Context context, VoiceRecognitionListener listener) {
        this.context  = context.getApplicationContext();
        this.listener = listener;
        initRecognizer();
    }

    // ──────────────────────────────────────────────────────────
    // Public API
    // ──────────────────────────────────────────────────────────

    /** Begin a single-shot recognition session. */
    public void startListening() {
        if (recognizer == null) {
            initRecognizer();
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        // Prefer offline model — works on devices with offline language pack.
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,          true);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,                Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,             3);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,         false);

        // Give the user 5 s of silence before timing out.
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 500L);

        try {
            recognizer.startListening(intent);
        } catch (Exception e) {
            Log.e(TAG, "startListening() threw: " + e.getMessage());
            listener.onRecognitionError(-1, "Could not start speech recognizer");
        }
    }

    /** Cancel any in-progress recognition. */
    public void stopListening() {
        if (recognizer != null) {
            try {
                recognizer.stopListening();
            } catch (Exception ignored) { }
        }
    }

    /** Release all resources — call from Activity.onDestroy(). */
    public void destroy() {
        if (recognizer != null) {
            try {
                recognizer.cancel();
                recognizer.destroy();
            } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    // ──────────────────────────────────────────────────────────
    // Internal helpers
    // ──────────────────────────────────────────────────────────

    private void initRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "SpeechRecognizer not available on this device");
            return;
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(context);
        recognizer.setRecognitionListener(new InternalListener());
    }

    // ──────────────────────────────────────────────────────────
    // RecognitionListener implementation (private inner class)
    // ──────────────────────────────────────────────────────────

    private class InternalListener implements RecognitionListener {

        @Override
        public void onReadyForSpeech(Bundle params) {
            Log.d(TAG, "onReadyForSpeech");
            listener.onReadyForSpeech();
        }

        @Override
        public void onBeginningOfSpeech() {
            Log.d(TAG, "onBeginningOfSpeech");
        }

        @Override
        public void onRmsChanged(float rmsdB) {
            // Could animate waveform here; skipped for clarity.
        }

        @Override
        public void onBufferReceived(byte[] buffer) { }

        @Override
        public void onEndOfSpeech() {
            Log.d(TAG, "onEndOfSpeech");
        }

        @Override
        public void onError(int error) {
            String msg = speechErrorToString(error);
            Log.w(TAG, "onError: " + msg + " (" + error + ")");

            // ERROR_NO_MATCH and ERROR_SPEECH_TIMEOUT are "soft" — user just
            // needs to try again.  All other errors are logged the same way.
            listener.onRecognitionError(error, msg);

            // Re-initialise so the recognizer can be used again.
            destroy();
            initRecognizer();
        }

        @Override
        public void onResults(Bundle results) {
            ArrayList<String> matches =
                    results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

            if (matches != null && !matches.isEmpty()) {
                String best = matches.get(0);
                Log.d(TAG, "onResults best=" + best);
                listener.onRecognitionResult(best);
            } else {
                listener.onRecognitionError(-1, "No speech detected");
            }
        }

        @Override
        public void onPartialResults(Bundle partialResults) { }

        @Override
        public void onEvent(int eventType, Bundle params) { }

        // Map SpeechRecognizer error codes to readable strings.
        private String speechErrorToString(int error) {
            switch (error) {
                case SpeechRecognizer.ERROR_AUDIO:               return "Audio recording error";
                case SpeechRecognizer.ERROR_CLIENT:              return "Client side error";
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    return "Insufficient permissions";
                case SpeechRecognizer.ERROR_NETWORK:             return "Network error";
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:     return "Network timeout";
                case SpeechRecognizer.ERROR_NO_MATCH:            return "No speech match found";
                case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:     return "Recognizer busy";
                case SpeechRecognizer.ERROR_SERVER:              return "Server error";
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:      return "No speech input detected";
                default:                                         return "Unknown error";
            }
        }
    }
}
