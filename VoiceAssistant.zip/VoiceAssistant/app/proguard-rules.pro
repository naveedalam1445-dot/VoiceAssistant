# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# Keep all voice assistant classes
-keep class com.voiceassistant.** { *; }

# Keep Android speech APIs
-keep class android.speech.** { *; }

# Keep Bluetooth adapter
-keep class android.bluetooth.** { *; }
